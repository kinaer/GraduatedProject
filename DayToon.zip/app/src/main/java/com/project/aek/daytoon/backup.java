package com.project.aek.daytoon;

/**
 * Created by Admin on 2017-01-16.
 */

public class backup {

            /*
        if (tag.equals("0")) {
            seleted_number = 0;
        } else if (tag.equals("1")) {
            seleted_number = 0;
        } else if (tag.equals("2")) {
            seleted_number = 0;
        } else if (tag.equals("3")) {

        } else if (tag.equals("4")) {

        } else if (tag.equals("5")) {

        }
        */

            /*
        Bitmap photo = null;

        if ( extras.containsKey("data") ) {
            photo = extras.getParcelable("data");
        }
        */

                    /*
                // 임시 파일 삭제
                File f = new File(mImageCaptureUri.getPath());
                if (f.exists()) {
                    f.delete();
                }
                */


                    /*
                    Bitmap photo = BitmapFactory.decodeFile(path);

                    BitmapDrawable drawable = new BitmapDrawable(getResources(), photo);

                    iv_UserPhoto.setBackground(drawable);
                    */

        /*
        try {

            //File f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), word+".png");
            File f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"DayToon");
            //f.createNewFile();

            String path = f.getAbsolutePath();

            boolean check = f.isDirectory();

            File f2 = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"DayToon/" + "a.png");

            String path2 = f2.getAbsolutePath();

            f2.createNewFile();

        } catch (IOException e) {

            Log.d("_test","err:" + e.getMessage());

        }
        */
}
